from django.apps import AppConfig


class CreditcardConfig(AppConfig):
    name = 'creditcard'
